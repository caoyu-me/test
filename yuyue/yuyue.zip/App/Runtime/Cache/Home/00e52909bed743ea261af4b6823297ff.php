<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>首页</title>

    <link href="/Public/Home/css/amazeuipc.css" rel="stylesheet" type="text/css"/>
    <link href="/Public/Home/css/admin.css" rel="stylesheet" type="text/css"/>

    <link href="/Public/Home/css/demo.css" rel="stylesheet" type="text/css"/>

    <link href="/Public/Home/css/hmstylepc.css" rel="stylesheet" type="text/css"/>
    <link href="/Public/Home/css/skin.css" rel="stylesheet" type="text/css"/>
    <script src="/Public/Home/js/jquery.min.js"></script>
    <script src="/Public/Home/js/amazeui.min.js"></script>

</head>

<body>
 <div class="hmtop">
    <!--顶部导航条 -->
    <div class="am-container header">
        <ul class="message-l">
            <div class="topMessage">
                <div class="menu-hd">
                    <a href="/">首页</a>&nbsp;&nbsp;
                    <?php if($_SESSION['user_id']=='' ): ?><a href="<?php echo U('/login');?>" target="_top" class="h">登录</a>&nbsp;&nbsp;
                    <a href="<?php echo U('/register');?>" target="_top">免费注册</a>
                    <?php else: ?>
                        <a href="<?php echo U('/user');?>" ><span style="color: #9d9d9d">
                            <?php if($user['name']=='' ): echo ($user["tel"]); ?>
                                <?php elseif($user['tel']==''): ?>
                                    <?php echo ($user["email"]); ?>
                                    <?php else: ?>
                                <?php echo ($user["name"]); endif; ?>
                            </span>
                        </a> &nbsp;
                        <a href="<?php echo U('/login/logout');?>">退出</a><?php endif; ?>
                </div>
            </div>
        </ul>
        <ul class="message-r">
            <div class="topMessage home">
                <div class="menu-hd"><a href="<?php echo U('/user/service');?>" target="_top" class="h">我的预约</a></div>
            </div>
            <div class="topMessage favorite">
                <div class="menu-hd"><a href="#" target="_top"><span>帮助</span></a>
                </div>
            </div>
        </ul>
    </div>

    <!--悬浮搜索框-->

    <div class="nav white">
         <div class="logoBig">
            <li><a href="/"><img src="/Public/Home/images/logobig.png"/></a></li>
        </div>

        <div class="search-bar pr">
            <a name="index_none_header_sysc" href="#"></a>
            <form>
                <input id="searchInput" name="index_none_header_sysc" type="text" placeholder="搜索" autocomplete="off">
                <input id="ai-topsearch" class="submit am-btn" value="搜索" index="1" type="submit">
            </form>
        </div>
    </div>

    <div class="clear"></div>
</div>
<div class="banner" style="top: 125px;">
    <!--轮播 -->
    <div class="am-slider am-slider-default scoll" data-am-flexslider id="demo-slider-0">
        <ul class="am-slides">
            <?php if(is_array($banner)): $i = 0; $__LIST__ = $banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><li class="banner1"><a href="<?php echo ($val["url"]); ?>"><img src="<?php echo ($val["pic"]); ?>"/></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="shopNav">
    <div class="slideall" style="padding-top: 0;">


        <!--侧边导航 -->

        <!--轮播-->




        <!--小导航 -->
        <div class="am-g am-g-fixed smallnav">
            <div class="am-u-sm-3">
                <a href="yuyue_information.html"><img src="/Public/Home/images/navsmall.jpg"/>
                    <div class="title">个人资料</div>
                </a>
            </div>
            <div class="am-u-sm-3">
                <a href="yuyue3.html"><img src="/Public/Home/images/huismall.jpg"/>
                    <div class="title">我的预约</div>
                </a>
            </div>
            <div class="am-u-sm-3">
                <a href="yuyue_register.html"><img src="/Public/Home/images/mansmall.jpg"/>
                    <div class="title">注册</div>
                </a>
            </div>
            <div class="am-u-sm-3">
                <a href="yuyue_login.html"><img src="/Public/Home/images/moneysmall.jpg"/>
                    <div class="title">登录</div>
                </a>
            </div>
        </div>

        <!--走马灯 -->


    </div>
    <script type="text/javascript">
        if ($(window).width() < 640) {
            function autoScroll(obj) {
                $(obj).find("ul").animate({
                    marginTop: "-39px"
                }, 500, function () {
                    $(this).css({
                        marginTop: "0px"
                    }).find("li:first").appendTo(this);
                })
            }

            $(function () {
                setInterval('autoScroll(".demo")', 3000);
            })
        }
    </script>
</div>
<div class="shopMainbg">
    <div class="shopMain" id="shopmain">

        <!--今日推荐 -->

        <!--热门活动 -->

        <div class="am-container activity ">

            <div class="am-g am-g-fixed " id="data-p" data-p='2'>
                <?php if(is_array($mall)): $i = 0; $__LIST__ = $mall;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><div class="am-u-sm-6 am-u-md-6 am-u-lg-3" style="padding: 0.25rem;padding-bottom:0">
                    <div class="activityMain ">
                        <!--这个层为外面的父层，只需设置相对位置样式即可  -->
                        <!--这个为里面要叠加的层，只需设置绝对样式  -->
                        <!--这个为层里面的内容图片  -->
                        <?php if($val['number'] ==0 ): ?><div style="position: relative;">
                          <div style="position: absolute;">
                              <img class="shouwan" src="/Public/Home/images/shouwan.png"/>
                          </div>
                            <a href="<?php echo U('/mall/index',array('id'=>$val['id']));?>"> <img src="<?php echo ($val['thumb']); ?>"/></a>
                        </div>
                            <?php else: ?>
                            <a href="<?php echo U('/mall/index',array('id'=>$val['id']));?>"><img src="<?php echo ($val['thumb']); ?>"/></a><?php endif; ?>
                     </div>
                    <div class="info clearfix" style="">
                        <h3> <a href="<?php echo U('/mall/index',array('id'=>$val['id']));?>"><?php echo ($val['title']); ?></a></h3>
                        <span class="xxxx"><?php echo ($val["intro"]); ?></span>
                    </div>
                    <div class="info clearfix"
                         style="background: #e61414;position: relative; height: 50px;padding-top: 0;padding-bottom: 0;">
                        <div class="now_pri">¥<i><?php echo ($val["price"]); ?></i></div>
                        <div class="rub">
                            抢！
                        </div>
                    </div>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="none"></div>
         </div>

        <div class="clear "></div>

       <div class="footer ">
    <div class="footer-bd " style="text-align: center;margin: 10px 0;">
        <?php echo (C("home_footer")); ?>
    </div>
</div>
<script src="/Public/Home/layer/layer.js"></script>


    </div>
</div>

<script>
    window.jQuery || document.write('<script src="/Public/Home/js/jquery.min.js "><\/script>');
</script>
<script type="text/javascript " src="/Public/Home/js/quick_links.js "></script>
<!--轮播-->
 <script type="text/javascript">
     (function () {
         $('.am-slider').flexslider();
     });
     $(document).ready(function () {
         $("li").hover(function () {
             $(".category-content .category-list li.first .menu-in").css("display", "none");
             $(".category-content .category-list li.first").removeClass("hover");
             $(this).addClass("hover");
             $(this).children("div.menu-in").css("display", "block")
         }, function () {
             $(this).removeClass("hover")
             $(this).children("div.menu-in").css("display", "none")
         });
     })
 </script>
<!--无限加载-->
 <script>
     //ajax 请求
     function ajax_data(p) {
         $.ajax({
             type: "POST",
             url: "<?php echo U('/index/ajax');?>",
             data: {
                 p:p,
             },
             dataType:"json",
             success: function(res){
                  if(res.err == '1'){
                     $(".none").hide();
                     var p= Number($('#data-p').attr('data-p'))+1;
                     //分页+1
                     $('#data-p').attr('data-p',p);
                     var html= "";
                     for($i=0;$i< res.mess.length;$i++)
                     {
                         var mall= res.mess[$i];
                         var link = '/mall/index/id/'+mall['id'];
                         var shouwan=''
                         if(mall['number'] == 0 ){
                              shouwan = "<div style='position: relative;'><div style='position: absolute;'><img class='shouwan' src='/Public/Home/images/shouwan.png'/></div><a href='"+link+"'> <img src='"+mall['thumb']+"'/></a></div>";
                         }else{
                             shouwan = "<a href='"+link+"'> <img src='"+mall['thumb']+"'/></a>";
                         }
                         html+="  <div class='am-u-sm-6 am-u-md-6 am-u-lg-3' style='padding: 0.25rem;padding-bottom:0'><div class='activityMain '>  "+shouwan+"</div><div class='info clearfix' style=''><h3> <a href='"+link+"'>"+mall['title']+"</a></h3><span class='xxxx'>"+mall['intro']+"</span></div><div class='info clearfix'style='background: #e61414;position: relative; height: 50px;padding-top: 0;padding-bottom: 0;'><div class='now_pri'>¥<i>"+mall['price']+"</i></div><div class='rub'>抢！</div></div></div> ";
                     }
                      layer.load(2);
                      setTimeout(function(){
                          layer.closeAll('loading');
                      }, 500);
                     $("#data-p").append(html);
                 }else{
                      $(".none").show();
                     $(".none").attr('die-value',2);
                 }
             },
             error:function (e) {
                 alert(e);
             }
         });
     }
     //下拉请求
     $(window).scroll(function () {
         var scrollTop = $(window).scrollTop();
         var documentHeight = $(document).height();
         var windowHeight = $(window).height();

         if(scrollTop + windowHeight == documentHeight) {
            if($('.none').attr('die-value')=='2'){
//                $('.none').html('暂无数据')
                return false;
            }
             var p= $('#data-p').attr('data-p');
              ajax_data(p);
         }
     });
 </script>
</body>

</html>