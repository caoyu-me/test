<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
    <title>注册</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />

    <link rel="stylesheet" href="/Public/Home/css/amazeui.min.css" />
    <link href="/Public/Home/css/dlstylepc.css" rel="stylesheet" type="text/css">
    <script src="/Public/Home/js/jquery.min.js"></script>
    <script src="/Public/Home/js/amazeui.min.js"></script>
    <script src="/Public/Home/js/me_cookie.js"></script>
    <style>
        .show2 p{text-indent: 2em;}
    </style>
</head>

<body>

<div class="login-boxtitle">
    <a href="/"><img alt="" src="/Public/Home/images/logobig.png" /></a>
</div>

<div class="res-banner">
    <div class="res-main">
        <div class="login-banner-bg"><span></span><img src="/Public/Home/images/big.jpg" /></div>
        <div class="reg_login-box">

            <div class="am-tabs" id="doc-my-tabs">

                <ul class="am-tabs-nav am-nav am-nav-tabs am-nav-justify">

                    <li ><a href="">登录</a></li>
                    <li class="am-active"><a href="">注册</a></li>
                </ul>

                <div class="am-tabs-bd">
                    <div class="am-tab-panel ">
                        <form action="<?php echo U('/login/login');?>" id="login" method="post">
                            <div class="user-name">
                                <label for="user"><i class="am-icon-user"></i></label>
                                <input type="text" name="username" id="user" placeholder="邮箱/手机/用户名">
                            </div>
                            <div class="user-pass">
                                <label for="password"><i class="am-icon-lock"></i></label>
                                <input type="password" name="pwd" id="password" placeholder="登录密码">
                            </div>
                            <div class="user-code">
                                <label for="password"><i class="am-icon-lock"></i></label>
                                <input type="text" name="verify"  placeholder="请输入验证码" >
                                <img style="cursor:pointer;" src="<?php echo U('/register/verify');?>" title="看不清楚？点击刷新" onclick="this.src = '<?php echo U('/register/verify');?>?'+new Date().getTime()" id="verify_code">
                            </div>
                        </form>
                        <div class="login-links">
                            <label for="remember-me"><input id="remember-me" type="checkbox" checked>&nbsp;记住密码</label>
                            <a href="<?php echo U('/reset');?>" class="am-fr">忘记密码</a>
                        </div>
                        <div class="am-cf">
                            <input type="submit" name="" value="登 录" onclick="login()" class="am-btn am-btn-primary am-btn-sm">
                        </div>

                    </div>

                    <div class="am-tab-panel am-active">
                        <form method="post" action="<?php echo U('/register/add');?>" id="reg">
                            <input type="hidden" name="invalid" value="" id="invalid">
                            <div class="user-email">
                                <label for="data_val"><i class="am-icon-user"></i></label>
                                <input type="text" name="data_val" id="data_val" placeholder="请输入手机号或邮箱账号">
                            </div>
                            <div class="verification">
                                <label for="code"><i class="am-icon-code-fork"></i></label>
                                <input type="tel" name="code" id="code" placeholder="请输入验证码">
                                <a class="btn" href="javascript:void(0);" onclick="sendMobileCode();" >
                                    <button id="dyMobileButton" class="huoqu"  type="button">获取</button></a>
                            </div>
                            <div class="user-pass">
                                <label for="password"><i class="am-icon-lock"></i></label>
                                <input type="password" name="pwd"  class="password" placeholder="密码(6-21字母、数字和符号组成)">
                            </div>

                        </form >

                        <div class="login-links">
                            <label for="reader-me">
                                <input id="reader-me" type="checkbox" checked name="agreement" value="1"> 点击表示您同意商城
                            </label>
                            <a onclick="showthis()">《服务协议》</a>
                        </div>

                        <div class="am-cf">
                            <input type="submit" name="" value="注册" onclick="reg()" class="am-btn am-btn-primary am-btn-sm am-fl">
                        </div>

                    </div>

                    <script>
                        $(function() {
                            $('#doc-my-tabs').tabs();
                        })
                    </script>

                </div>
            </div>

        </div>
    </div>

    <div class="footer ">
    <div class="footer-bd " style="text-align: center;margin: 10px 0;">
        <?php echo (C("home_footer")); ?>
    </div>
</div>
<script src="/Public/Home/layer/layer.js"></script>



    <div class="show1" style="background: rgba(0,0,0,0.7);position: absolute;width: 100%;height: 100%;z-index: 108;top: 0;left: 0;display: none;" onclick="hidethis()">

    </div>
</body>
<script>
    function showthis(){
        $(".show1").show();
        $(".show2").show();
    }
    function hidethis(){
        $(".show1").hide();
        $(".show2").hide();
    }
</script>
<script>
    //定时
    var countdown =10;
    //coolie 判断
    console.log(cookieget('code'));
    console.log(cookieget('invalid'));
    if(cookieget('code') > 0 && 10 > cookieget('code')){
        countdown = Number(cookieget('code'));
        var int = setInterval(function () { timeout();}, 1000)
    }else{
        cookiesave('code',0,'','','');
    }
    if(cookieget('invalid')){
        $('#invalid').val(cookieget('invalid'));
    }
    //发送验证码
    function SendCode(value,type) {
        $.ajax({
            url: "<?php echo U('Home/code/index');?>",
            data: {
                value: value,
                type:type,
                //发送的格式 1 验证码。2 地址链接
                type2:1,
            },
            dataType: "json",
            type: "post",
            success: function (result) {
                console.log(result);
                cookiesave('invalid',result.invalid,'','','');
                switch (result.err){
                    case -2:
                        alert('邮箱格式错误');
                        countdown =Number(0);
                        break;
                    case -1:
                        alert('手机号码格式错误');
                        countdown =Number(0);
                        break;
                    case 0:
                        alert('发送成功');
                        console.log(result);
                        $('#invalid').val(result.invalid)
                        cookiesave('code',10,'','','');
                        break;
                    case 1:
                        alert('在指定时间内不能重复发送,请在等待'+result.sytimer+'秒');
                        console.log(result);
                        $('#invalid').val(result.invalid)
                        countdown =Number(0);
                        break;
                    case 2:
                        alert('当前请求类型错误');
                        countdown =Number(0);
                        break;
                    case 3:
                        alert('邮箱发送失败');
                        countdown =Number(0);
                        break;
                    case 4:
                        alert('短信发送失败');
                        countdown =Number(0);
                        break;
                    case 5:
                        alert('该号码已存在！');
                        cookiesave('code',0,'','','');
                        window.location.reload();
                        break;
                    case 6:
                        alert('该邮箱已存在！');
                        cookiesave('code',0,'','','');
                        window.location.reload();
                        break;
                }
            },
            error: function (xmlHttpRequest) {
                console.log(xmlHttpRequest.responseText);
//                if (xmlHttpRequest.status == 501) {
//                    window.location.href = '../timeout.html';
//                }
            }
        });
    }
    var email_code = /\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/;
    var pwd_code = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;
    var tel_code =/0?(13|14|15|17|18)[0-9]{9}/;

    //点击发送 验证码
    function sendMobileCode() {
        var data_val = $("#data_val").val();
        var type = '';
        if (email_code.test(data_val) || tel_code.test(data_val) ) {
            if(email_code.test(data_val)){
                type='email';
            }else if(tel_code.test(data_val)){
                type='tel';
            }
            if (countdown == 10) {
                //发送验证码
                SendCode(data_val,type);
            }

            if(countdown == 0){
                $('.huoqu').removeAttr('disabled');
                $('.huoqu').html( "获取");
                countdown = 10;
                cookiesave('code',countdown,'','','');
                //阻止冒泡
                clearTimeout(clear);
                return false;
            }else {
                $('.huoqu').attr("disabled", 'disabled');
                $('.huoqu').html(" "+countdown+"  ");
                countdown -= 1;
                cookiesave('code', countdown, '', '', '');
            }
            //定时
            clear = setTimeout("sendMobileCode()", 1000);
        } else {
            alert('请输入正确的邮箱/手机号');
            return;
        }
    }
    //密码判断
    $(".password").blur(function () {
        var pwd_val=$(this).val();
        if (pwd_code.test(pwd_val)) {

        }else{
            alert('密码由6-21字母和数字组成，不能是纯数字或纯英文');
        }
    });
    //发送验证码框 时间限制

    function timeout() {
        if(countdown == 0){
            $('.huoqu').removeAttr('disabled');
            $('.huoqu').html("获取");
            countdown = 10;
            cookiesave('code',countdown,'','','');
            clearInterval(int);
            return false;
        }else{
            $('.huoqu').attr("disabled", 'disabled');
            $('.huoqu').html(" "+countdown+" ");
            countdown-=1;
            cookiesave('code',countdown,'','','');
        }

    }

    //登录
    function login() {
        var data_value =$('#user').val();
        if(data_value == ''){
            alert('请填写正确的手机号或邮箱！');
            $('#verify_code').click();
            return;
        }
        $('#login').submit();
    }
    //注册
    function reg() {
        var data_value =$('#data_val').val();
        if(data_value == ''){
            alert('请填写正确的手机号或邮箱！');
            return;
        }
        $('#reg').submit();
    }

</script>
</html>