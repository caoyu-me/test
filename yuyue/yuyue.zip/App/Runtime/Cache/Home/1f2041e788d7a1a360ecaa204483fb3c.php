<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>商品页面</title>

    <link href="/Public/Home/css/admin.css" rel="stylesheet" type="text/css" />
    <link href="/Public/Home/css/amazeuipc.css" rel="stylesheet" type="text/css" />
    <link href="/Public/Home/css/demo.css" rel="stylesheet" type="text/css" />
    <link type="text/css" href="/Public/Home/css/optstyle.css" rel="stylesheet" />
    <link type="text/css" href="/Public/Home/css/stylepc.css" rel="stylesheet" />

    <script type="text/javascript" src="/Public/Home/js/jquery-1.7.min.js"></script>
    <script type="text/javascript" src="/Public/Home/js/quick_links.js"></script>

    <script type="text/javascript" src="/Public/Home/js/amazeui.js"></script>
    <script type="text/javascript" src="/Public/Home/js/jquery.imagezoom.min.js"></script>
    <script type="text/javascript" src="/Public/Home/js/jquery.flexslider.js"></script>
    <script type="text/javascript" src="/Public/Home/js/list.js"></script>

</head>

<body>


 <div class="hmtop">
    <!--顶部导航条 -->
    <div class="am-container header">
        <ul class="message-l">
            <div class="topMessage">
                <div class="menu-hd">
                    <a href="/">首页</a>&nbsp;&nbsp;
                    <?php if($_SESSION['user_id']=='' ): ?><a href="<?php echo U('/login');?>" target="_top" class="h">登录</a>&nbsp;&nbsp;
                    <a href="<?php echo U('/register');?>" target="_top">免费注册</a>
                    <?php else: ?>
                        <a href="<?php echo U('/user');?>" ><span style="color: #9d9d9d">
                            <?php if($user['name']=='' ): echo ($user["tel"]); ?>
                                <?php elseif($user['tel']==''): ?>
                                    <?php echo ($user["email"]); ?>
                                    <?php else: ?>
                                <?php echo ($user["name"]); endif; ?>
                            </span>
                        </a> &nbsp;
                        <a href="<?php echo U('/login/logout');?>">退出</a><?php endif; ?>
                </div>
            </div>
        </ul>
        <ul class="message-r">
            <div class="topMessage home">
                <div class="menu-hd"><a href="<?php echo U('/user/service');?>" target="_top" class="h">我的预约</a></div>
            </div>
            <div class="topMessage favorite">
                <div class="menu-hd"><a href="#" target="_top"><span>帮助</span></a>
                </div>
            </div>
        </ul>
    </div>

    <!--悬浮搜索框-->

    <div class="nav white">
         <div class="logoBig">
            <li><a href="/"><img src="/Public/Home/images/logobig.png"/></a></li>
        </div>

        <div class="search-bar pr">
            <a name="index_none_header_sysc" href="#"></a>
            <form>
                <input id="searchInput" name="index_none_header_sysc" type="text" placeholder="搜索" autocomplete="off">
                <input id="ai-topsearch" class="submit am-btn" value="搜索" index="1" type="submit">
            </form>
        </div>
    </div>

    <div class="clear"></div>
</div>

<div class="listMain">

    <!--分类-->
    <script type="text/javascript">
        $(function() {});
        $(window).load(function() {
            $('.flexslider').flexslider({
                animation: "slide",
                start: function(slider) {
                    $('body').removeClass('loading');
                }
            });
        });
    </script>
    <div class="scoll">
        <section class="slider">
            <div class="flexslider">
                <ul class="slides">
                    <li>
                        <img src="/Public/Home/images/01.jpg" title="pic" />
                    </li>
                    <li>
                        <img src="/Public/Home/images/02.jpg" />
                    </li>
                    <li>
                        <img src="/Public/Home/images/03.jpg" />
                    </li>
                </ul>
            </div>
        </section>
    </div>

    <!--放大镜-->

    <div class="item-inform">
        <div class="clearfixLeft" id="clearcontent">

            <div class="box">
                <script type="text/javascript">
                    $(document).ready(function() {
                        $(".jqzoom").imagezoom();
                        $("#thumblist li a").click(function() {
                            $(this).parents("li").addClass("tb-selected").siblings().removeClass("tb-selected");
                            $(".jqzoom").attr('src', $(this).find("img").attr("mid"));
                            $(".jqzoom").attr('rel', $(this).find("img").attr("big"));
                        });
                    });
                </script>

                <div class="tb-booth tb-pic tb-s310">
                    <a href="<?php echo ($mall['pic'][0]); ?>"><img src="<?php echo ($mall['pic'][0]); ?>"  rel="<?php echo ($mall['pic'][0]); ?>" class="jqzoom" /></a>
                </div>

                <ul class="tb-thumb" id="thumblist">

                    <li class="tb-selected">
                        <div class="tb-pic tb-s40">
                            <a href="#"><img src="<?php echo ($mall['pic'][0]); ?>"  mid="<?php echo ($mall['pic'][0]); ?>" big="<?php echo ($mall['pic'][0]); ?>"></a>
                        </div>
                    </li>
                    <li class="tb-selected">
                        <div class="tb-pic tb-s40">
                            <a href="#"><img src="<?php echo ($mall['pic'][1]); ?>" mid="<?php echo ($mall['pic'][1]); ?>" big="<?php echo ($mall['pic'][1]); ?> " ></a>
                        </div>
                    </li>
                    <li class="tb-selected">
                        <div class="tb-pic tb-s40">
                            <a href="#"><img src="<?php echo ($mall['pic'][2]); ?>" mid="<?php echo ($mall['pic'][2]); ?>" big="<?php echo ($mall['pic'][2]); ?>"></a>
                        </div>
                    </li>

                </ul>
            </div>

            <div class="clear"></div>
        </div>

        <div class="clearfixRight">

            <!--规格属性-->
            <!--名称-->
            <div class="tb-detail-hd">
                <h1>
                    <?php echo ($mall["title"]); ?>
                </h1>
            </div>
            <div class="tb-detail-list">
                <!--价格-->
                <div class="tb-detail-price">
                    <li class="price iteminfo_price">
                        <dt>促销价</dt>
                        <dd><em>¥</em><b class="sys_item_price"><?php echo ($mall["price"]); ?></b>  </dd>
                    </li>

                    <div class="clear"></div>
                </div>
            </div>

            <div class="pay">
                <div class="pay-opt">
                    <a href="yuyue.html"><span class="am-icon-home am-icon-fw">首页</span></a>
                    <a><span class="am-icon-heart am-icon-fw">收藏</span></a>

                </div>

                <li>
                    <div class="clearfix tb-btn tb-btn-basket theme-login">
                        <a id="LikBasket" title="加入购物车" href="javascript:;" ><i></i>马上预约</a>
                        <input type="hidden" value="<?php echo ($user["id"]); ?>" name="user_id" id="user_id">
                        <input type="hidden" value="<?php echo ($mall["id"]); ?>" name="mall_id" id="mall_id">
                    </div>
                </li>
            </div>

        </div>

        <div class="clear"></div>

    </div>
    <!-- introduce-->

    <div class="introduce">
        <div class="browse">
            <div class="mc">
                <ul>
                    <div class="mt">
                        <h2>看了又看</h2>
                    </div>
                    <?php if(is_array($recommend)): $i = 0; $__LIST__ = $recommend;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><li class="first">
                        <div class="p-img">
                            <a  href="<?php echo U('/mall/index',array('id'=>$val['id']));?>"> <img class="" src="<?php echo ($val["thumb"]); ?>"> </a>
                        </div>
                        <div class="p-name"><a href="<?php echo U('/mall/index',array('id'=>$val['id']));?>">
                            <?php echo ($val["intro"]); ?>
                        </a>
                        </div>
                        <div class="p-price"><strong>￥<?php echo ($val["price"]); ?></strong></div>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>


                </ul>
            </div>
        </div>
        <div class="introduceMain">
            <div class="am-tabs" data-am-tabs>
                <ul class="am-avg-sm-3 am-tabs-nav am-nav am-nav-tabs">
                    <li class="am-active">
                        <a href="#">

                            <span class="index-needs-dt-txt">宝贝详情</span></a>

                    </li>

                </ul>
                <!--富文本-->
                <div class="am-tabs-bd">
                    <?php echo html_entity_decode($mall['body']);?>
                </div>

            </div>

            <div class="clear"></div>

            <div class="footer ">
    <div class="footer-bd " style="text-align: center;margin: 10px 0;">
        <?php echo (C("home_footer")); ?>
    </div>
</div>
<script src="/Public/Home/layer/layer.js"></script>

        </div>

    </div>
</div>

</body>
<script>
    //请求
    $('#LikBasket').click(function () {
        var mall_id = $('#mall_id').val();
        var user_id = $('#user_id').val();
         if(user_id){
             $.ajax({
                 type: "POST",
                 url: "<?php echo U('/mall/yuyue/');?>",
                 data: {
                     mall_id:mall_id ,
                 },
                 dataType:"json",
                 success: function(res){
                     console.log(res);
                    if(res.err == '1'){
                        layer.alert(res.msg+'兑换码：<br>'+res.code);
                    }else if(res.err == '0'){
                        layer.alert(res.msg+'兑换码：<br>'+res.code);
                    }else if(res.err == '-1'){
                        layer.alert(res.msg);
                    }
                 },
                 error:function (res,errq) {
                     alert(errq);
                 }
             });

         }else{
            alert('请先登录，谢谢合作');
        }
    });


</script>
</html>