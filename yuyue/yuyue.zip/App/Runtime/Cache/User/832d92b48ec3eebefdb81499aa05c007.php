<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0">

    <title>订单管理</title>

    <link href="/Public/Home/css/admin.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/amazeuipc.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/b_page.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/personal.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/orstyle.css" rel="stylesheet" type="text/css">

    <script src="/Public/Home/js/jquery.min.js"></script>
    <script src="/Public/Home/js/amazeui.js"></script>

</head>

<body>
<!--头 -->
<div class="hmtop">
    <!--顶部导航条 -->
    <div class="am-container header">
        <ul class="message-l">
            <div class="topMessage">
                <div class="menu-hd">
                    <a href="/">首页</a>&nbsp;&nbsp;
                    <?php if($_SESSION['user_id']=='' ): ?><a href="<?php echo U('/login');?>" target="_top" class="h">登录</a>&nbsp;&nbsp;
                    <a href="<?php echo U('/register');?>" target="_top">免费注册</a>
                    <?php else: ?>
                        <a href="<?php echo U('/user');?>" ><span style="color: #9d9d9d">
                            <?php if($user['name']=='' ): echo ($user["tel"]); ?>
                                <?php elseif($user['tel']==''): ?>
                                    <?php echo ($user["email"]); ?>
                                    <?php else: ?>
                                <?php echo ($user["name"]); endif; ?>
                            </span>
                        </a> &nbsp;
                        <a href="<?php echo U('/login/logout');?>">退出</a><?php endif; ?>
                </div>
            </div>
        </ul>
        <ul class="message-r">
            <div class="topMessage home">
                <div class="menu-hd"><a href="<?php echo U('/user/service');?>" target="_top" class="h">我的预约</a></div>
            </div>
            <div class="topMessage favorite">
                <div class="menu-hd"><a href="#" target="_top"><span>帮助</span></a>
                </div>
            </div>
        </ul>
    </div>

    <!--悬浮搜索框-->

    <div class="nav white">
         <div class="logoBig">
            <li><a href="/"><img src="/Public/Home/images/logobig.png"/></a></li>
        </div>

        <div class="search-bar pr">
            <a name="index_none_header_sysc" href="#"></a>
            <form>
                <input id="searchInput" name="index_none_header_sysc" type="text" placeholder="搜索" autocomplete="off">
                <input id="ai-topsearch" class="submit am-btn" value="搜索" index="1" type="submit">
            </form>
        </div>
    </div>

    <div class="clear"></div>
</div>

<div class="center">
    <div class="col-main">
        <div class="main-wrap">
            <div class="user-order">

                <!--标题 -->
                <div class="am-cf am-padding">
                    <div class="am-fl am-cf"><strong class="am-text-danger am-text-lg">我的预约</strong> /
                        <small>Order</small>
                    </div>
                </div>
                <hr/>
                <div class="am-tabs am-tabs-d2 am-margin" data-am-tabs>

                    <div class="am-tabs-bd">
                        <div class="am-tab-panel am-fade am-in am-active" id="tab1">
                            <div class="order-top">
                                <div class="th th-item" style="width: 70%;">
                                    <td class="td-inner">商品</td>
                                </div>
                                <div class="th th-status" style="width: 30%;">
                                    <td class="td-inner">预约码</td>
                                </div>
                            </div>

                            <div class="order-main">
                                <div class="order-list">
                                    <!--交易成功-->
                                    <?php if(is_array($redeem_code)): $i = 0; $__LIST__ = $redeem_code;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><div class="order-status5">
                                        <div class="order-title">
                                            <span>预约时间：<?php echo (substr($val["update_time"],0,10)); ?></span>
                                        </div>
                                        <div class="order-content clearfix" style="border: 1px solid #E4EAEE;">
                                            <div class="order-left" style="width: 70%;border:none;float: left;">

                                                <ul class="item-list">
                                                    <li class="td td-item" style="width: 100%;">
                                                        <div class="item-pic" style="margin-top: 0;">
                                                            <a href="#" class="J_MakePoint">
                                                                <img src="<?php echo ($val["thumb"]); ?>"
                                                                     class="itempic J_ItemImg">
                                                            </a>
                                                        </div>
                                                        <div class="item-info">
                                                            <div class="item-basic-info" style="padding-top: 0;">
                                                                <a href="#">
                                                                    <p><?php echo ($val["title"]); ?> </p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="order-right"
                                                 style="width: 30%; float: right;text-align: center;">
                                                <div class="am-btn am-btn-danger anniu" style="display: inline; " >
                                                  <?php echo ($val["code"]); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div><?php endforeach; endif; else: echo "" ;endif; ?>
                                </div>
                            </div>
                            <div class="b-page">
                            <?php echo ($page); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer ">
    <div class="footer-bd " style="text-align: center;margin: 10px 0;">
        <?php echo (C("home_footer")); ?>
    </div>
</div>
<script src="/Public/Home/layer/layer.js"></script>

    </div>
    <aside class="menu">
    <ul>
        <li class="person">
            <ul>
                <li><a href="<?php echo U('/user');?>">个人信息</a></li>
            </ul>
        </li>
        <li class="person">
            <ul>
                <li><a href="<?php echo U('/user/service');?>">我的预约</a></li>
            </ul>
        </li>
        <li class="person">
            <ul>
                <li><a href="<?php echo U('/user/pwd');?>">重置密码</a></li>
            </ul>
        </li>
        <li class="person">
            <ul>
                <li><a href="<?php echo U('/login/logout');?>">安全退出</a></li>
            </ul>
        </li>

    </ul>
</aside>
<script>
    var curr_url = window.location.pathname;  //获取当前URL
    $('.menu a').each(function(){  //循环导航的a标签
        var href = $(this).attr('href'); //a标签中的href链接
        if(href == curr_url){  //如果当前URL,和a标签中的href相等。
             $(this).parent().addClass('active');  //那么就给这个a标签增加home_page类。
        }
    })
</script>
</div>

</body>

</html>