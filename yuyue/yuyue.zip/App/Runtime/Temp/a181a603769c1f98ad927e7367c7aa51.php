<?php
//000000000000a:10:{s:8:"sitename";s:12:"乾元大通";s:5:"title";s:9:"SEO标题";s:8:"keywords";s:9:"关键词";s:11:"description";s:12:"网站描述";s:6:"footer";s:46:"邮箱:support@ry1000.com 苏ICP备17043932号";s:5:"plnum";s:2:"10";s:8:"plstatus";s:1:"0";s:8:"lystatys";s:1:"1";s:9:"telephone";s:13:"0515-17715677";s:7:"dlength";s:2:"10";}
?>