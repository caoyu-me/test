<?php
/**
 *
 * 版权所有：xxx
 * 作    者：曹宇
 * 日    期：2017-11-22
 * 版    本：1.0.0
 * 功能说明：个人中心进入判断。
 *
 **/

namespace User\Controller;

use Common\Controller\BaseController;
use Common\Controller\HomeController;
use Think\Auth;

class ComController extends HomeController
{

    public function _initialize()
    {
        parent::_initialize();

    }


}